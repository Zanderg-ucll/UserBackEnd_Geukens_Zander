package be.ucll.reeks59;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reeks59ApplicationTests {

	@Test
	void contextLoads() {
	}

}
