package be.ucll.reeks59.user.model;

public class Book {

    private String title;
    private int numberInStock;
    private boolean inColor;
    private double priceInDollar;
    private double priceInEuro;

    public Book(String title, int numberInStock, double priceInEuro, boolean inColor) {
        this.title = title;

        this.numberInStock = numberInStock;
        this.inColor = inColor;
        this.priceInEuro = priceInEuro;
        this.priceInDollar = (priceInEuro * 1.06);
    }

    public String getTitle() {
        return title;
    }

    public int getNumberInStock() {
        return numberInStock;
    }

    public boolean isInColor() {
        return inColor;
    }

    public double getPriceInDollar() {
        return priceInDollar;
    }

    public double getPrice() {
        return priceInEuro;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
