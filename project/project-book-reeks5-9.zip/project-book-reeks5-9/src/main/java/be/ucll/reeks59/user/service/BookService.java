package be.ucll.reeks59.user.service;

import java.util.*;
import org.springframework.stereotype.Service;

import be.ucll.reeks59.user.model.Book;

@Service
public class BookService {

    private List<Book> bookRepository;

    public List<Book> getBooks() {
        return bookRepository;
    }

    public BookService() {
        bookRepository = new ArrayList<>();
    }

    public boolean addBook(Book book) {
        bookRepository.add(book);
        return true;
    }

}